plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.nexus.tvdesktop"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.nexus.tvdesktop"
        minSdk = 23
        targetSdk = 28
        versionCode = 6
        versionName = "6.0-skyworth"
    }
}
