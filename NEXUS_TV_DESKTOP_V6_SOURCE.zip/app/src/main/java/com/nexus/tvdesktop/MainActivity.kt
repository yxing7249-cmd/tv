package com.nexus.tvdesktop

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Drawable
import android.content.ClipData
import android.view.DragEvent
import android.net.Uri
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("nexus_settings", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private lateinit var clockView: TextView
    private lateinit var grid: GridLayout
    private lateinit var categoryBar: LinearLayout
    private var selectedCategory = "全部"
    private var searchQuery = ""
    private val favoritePackages = mutableSetOf<String>()
    private lateinit var searchBox: EditText
    private var showAppIcons = true
    private var remoteSortMode = false
    private var focusedPackageBeforeRender: String? = null
    private val orderedPackages = mutableListOf<String>()
    private var allApps: List<ResolveInfo> = emptyList()
    private var backgroundView: ImageView? = null
    private val categories = listOf("全部", "收藏", "视频", "音乐", "游戏", "工具")

    private val clockTick = object : Runnable {
        override fun run() {
            if (::clockView.isInitialized) {
                val now = Date()
                val date = SimpleDateFormat("yyyy年MM月dd日  EEEE", Locale.getDefault()).format(now)
                val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
                clockView.text = "$time\n$date"
            }
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyImmersive()
        showAppIcons = prefs.getBoolean("show_app_icons", true)
        loadApps()
        favoritePackages.clear()
        favoritePackages.addAll(prefs.getString("favorite_apps", "")!!.split("|").filter { it.isNotBlank() })
        showDesktop()
    }

    private fun applyImmersive() {
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    override fun onResume() {
        super.onResume()
        applyImmersive()
        handler.removeCallbacks(clockTick)
        handler.post(clockTick)
    }

    override fun onPause() {
        handler.removeCallbacks(clockTick)
        super.onPause()
    }

    @Suppress("DEPRECATION")
    private fun loadApps() {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = packageManager.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
        orderedPackages.clear()
        orderedPackages.addAll(prefs.getString("app_order", "")!!.split("|").filter { it.isNotBlank() })
        allApps = allApps.sortedBy { app ->
            val index = orderedPackages.indexOf(app.activityInfo.packageName)
            if (index < 0) Int.MAX_VALUE else index
        }
    }

    private fun showDesktop() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(38, 24, 38, 20)
            setBackgroundColor(Color.rgb(8, 12, 22))
            isFocusableInTouchMode = true
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "NEXUS"
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        val edition = TextView(this).apply {
            text = "  TV DESKTOP  V6.0"
            textSize = 15f
            setTextColor(Color.rgb(0, 190, 255))
        }
        clockView = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.END
            setTextColor(Color.WHITE)
        }
        val spacer = Space(this)
        top.addView(logo)
        top.addView(edition)
        top.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(clockView)
        root.addView(top)

        categoryBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 18, 0, 14)
        }
        categories.forEach { category ->
            val tab = makeButton(category, 15f) { selectedCategory = category; renderApps() }
            categoryBar.addView(tab, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, 48
            ).apply { setMargins(0, 0, 10, 0) })
        }
        searchBox = EditText(this).apply {
            hint = "搜索应用"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 15f
            singleLine = true
            setPadding(12, 0, 12, 0)
            background = rounded(Color.rgb(25, 39, 60))
            setOnEditorActionListener { _, _, _ -> renderApps(); true }
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    searchQuery = s?.toString()?.trim().orEmpty()
                    renderApps()
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        categoryBar.addView(searchBox, LinearLayout.LayoutParams(190, 48).apply { setMargins(8, 0, 8, 0) })
        val settings = makeButton("⚙ 设置中心", 15f) { showSettings() }
        categoryBar.addView(settings)
        root.addView(categoryBar)

        grid = GridLayout(this).apply {
            columnCount = 5
            useDefaultMargins = true
            alignmentMode = GridLayout.ALIGN_BOUNDS
        }
        root.addView(grid, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        val footer = TextView(this).apply {
            text = "方向键选择应用   OK 打开   STAR 收藏/取消收藏   MENU 排序   BACK 留在桌面"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 10, 0, 0)
        }
        root.addView(footer)
        setContentView(root)
        applySavedWallpaper()
        renderApps()
        root.requestFocus()
    }

    private fun renderApps() {
        if (!::grid.isInitialized) return
        focusedPackageBeforeRender = focusedPackageBeforeRender ?: currentFocusedPackage()
        grid.removeAllViews()
        val filtered = allApps.filter { app ->
            val pkg = app.activityInfo.packageName
            val label = app.loadLabel(packageManager).toString()
            val categoryMatch = when (selectedCategory) {
                "全部" -> true
                "收藏" -> favoritePackages.contains(pkg)
                else -> appCategory(app) == selectedCategory
            }
            categoryMatch && (searchQuery.isBlank() ||
                label.contains(searchQuery, ignoreCase = true) ||
                pkg.contains(searchQuery, ignoreCase = true))
        }
        filtered.forEach { info ->
            val label = info.loadLabel(packageManager).toString()
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(8, 10, 8, 8)
                background = rounded(Color.rgb(25, 39, 60))
                isFocusable = true
                isClickable = true
                contentDescription = if (remoteSortMode) "编辑排序：$label" else "打开$label；菜单键编辑排序"
                val appIcon = try { info.loadIcon(packageManager) } catch (_: Exception) { null }
                if (showAppIcons && appIcon != null) {
                    val iconView = ImageView(this@MainActivity).apply {
                        setImageDrawable(appIcon)
                        scaleType = ImageView.ScaleType.FIT_CENTER
                    }
                    addView(iconView, LinearLayout.LayoutParams(48, 48).apply { bottomMargin = 7 })
                }
                val nameView = TextView(this@MainActivity).apply {
                    text = label
                    textSize = 15f
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    maxLines = 2
                }
                addView(nameView, LinearLayout.LayoutParams(-1, -2))
                setOnFocusChangeListener { v, focused ->
                    v.background = rounded(if (focused) {
                        if (remoteSortMode) Color.rgb(170, 92, 0) else Color.rgb(0, 105, 150)
                    } else Color.rgb(25, 39, 60))
                    v.scaleX = if (focused) 1.04f else 1f
                    v.scaleY = if (focused) 1.04f else 1f
                }
                setOnClickListener {
                    if (remoteSortMode) {
                        saveRemoteOrder()
                        return@setOnClickListener
                    }
                    val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                    if (launch != null) try { startActivity(launch) } catch (_: Exception) {
                        Toast.makeText(this@MainActivity, "无法打开此应用", Toast.LENGTH_SHORT).show()
                    }
                }
                setOnLongClickListener { view ->
                    val clip = ClipData.newPlainText("nexus_app", info.activityInfo.packageName)
                    view.startDragAndDrop(clip, View.DragShadowBuilder(view), info.activityInfo.packageName, 0)
                    true
                }
                setOnDragListener { target, event ->
                    when (event.action) {
                        DragEvent.ACTION_DRAG_STARTED -> event.clipDescription?.hasMimeType("text/plain") == true
                        DragEvent.ACTION_DRAG_ENTERED -> {
                            background = rounded(Color.rgb(0, 125, 170)); true
                        }
                        DragEvent.ACTION_DRAG_EXITED -> {
                            background = rounded(Color.rgb(25, 39, 60)); true
                        }
                        DragEvent.ACTION_DROP -> {
                            val fromPkg = event.localState as? String
                            val toPkg = info.activityInfo.packageName
                            if (fromPkg != null && fromPkg != toPkg) moveAppBefore(fromPkg, toPkg)
                            true
                        }
                        DragEvent.ACTION_DRAG_ENDED -> {
                            background = rounded(Color.rgb(25, 39, 60)); true
                        }
                        else -> true
                    }
                }
            }
            val params = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            ).apply { width = 0; height = 104; setMargins(7, 7, 7, 7) }
            grid.addView(tile, params)
        }
        if (filtered.isEmpty()) {
            val empty = TextView(this).apply {
                text = "此分类暂时没有应用"
                textSize = 20f
                setTextColor(Color.WHITE)
            }
            grid.addView(empty)
        } else {
            grid.getChildAt(0)?.requestFocus()
        }
    }

    private fun appCategory(info: ResolveInfo): String {
        val s = (info.loadLabel(packageManager).toString() + " " +
            info.activityInfo.packageName).lowercase(Locale.getDefault())
        return when {
            listOf("video", "tv", "movie", "netflix", "youtube", "爱奇艺", "腾讯视频", "优酷", "芒果").any { s.contains(it) } -> "视频"
            listOf("music", "audio", "radio", "音乐", "酷狗", "qqmusic").any { s.contains(it) } -> "音乐"
            listOf("game", "游戏", "play").any { s.contains(it) } -> "游戏"
            else -> "工具"
        }
    }

    private fun currentFocusedPackage(): String? {
        val focused = window.decorView.findFocus() ?: return null
        val index = (0 until grid.childCount).firstOrNull { grid.getChildAt(it) === focused }
        return index?.let { idx ->
            val visible = visibleApps()
            visible.getOrNull(idx)?.activityInfo?.packageName
        }
    }

    private fun visibleApps(): List<ResolveInfo> =
        allApps.filter { app ->
            val pkg = app.activityInfo.packageName
            val label = app.loadLabel(packageManager).toString()
            val categoryMatch = when (selectedCategory) {
                "全部" -> true
                "收藏" -> favoritePackages.contains(pkg)
                else -> appCategory(app) == selectedCategory
            }
            categoryMatch && (searchQuery.isBlank() ||
                label.contains(searchQuery, ignoreCase = true) ||
                pkg.contains(searchQuery, ignoreCase = true))
        }

    private fun enterRemoteSortMode() {
        if (remoteSortMode) return
        remoteSortMode = true
        focusedPackageBeforeRender = currentFocusedPackage()
        Toast.makeText(this, "排序编辑：方向键移动应用，OK 保存，返回键退出编辑", Toast.LENGTH_LONG).show()
        renderApps()
        focusSavedOrFirst()
    }

    private fun saveRemoteOrder() {
        remoteSortMode = false
        val order = allApps.map { it.activityInfo.packageName }
        orderedPackages.clear()
        orderedPackages.addAll(order)
        prefs.edit().putString("app_order", order.joinToString("|")).apply()
        focusedPackageBeforeRender = null
        renderApps()
        Toast.makeText(this, "应用排序已保存", Toast.LENGTH_SHORT).show()
    }

    private fun cancelRemoteSortMode() {
        remoteSortMode = false
        focusedPackageBeforeRender = null
        loadApps()
        renderApps()
        Toast.makeText(this, "已退出排序编辑", Toast.LENGTH_SHORT).show()
    }

    private fun focusSavedOrFirst() {
        val visible = visibleApps()
        val pkg = focusedPackageBeforeRender
        val index = if (pkg == null) 0 else visible.indexOfFirst { it.activityInfo.packageName == pkg }.let {
            if (it < 0) 0 else it
        }
        grid.getChildAt(index)?.requestFocus()
        focusedPackageBeforeRender = null
    }

    private fun moveFocusedApp(direction: Int) {
        val visible = visibleApps()
        val focused = window.decorView.findFocus() ?: return
        val fromIndex = (0 until grid.childCount).firstOrNull { grid.getChildAt(it) === focused } ?: return
        val toIndex = (fromIndex + direction).coerceIn(0, visible.size - 1)
        if (toIndex == fromIndex) return

        val movingPackage = visible[fromIndex].activityInfo.packageName
        val targetPackage = visible[toIndex].activityInfo.packageName
        val globalFrom = allApps.indexOfFirst { it.activityInfo.packageName == movingPackage }
        val globalTo = allApps.indexOfFirst { it.activityInfo.packageName == targetPackage }
        if (globalFrom < 0 || globalTo < 0) return

        val mutable = allApps.toMutableList()
        val item = mutable.removeAt(globalFrom)
        mutable.add(globalTo.coerceIn(0, mutable.size), item)
        allApps = mutable
        focusedPackageBeforeRender = movingPackage
        renderApps()
        focusSavedOrFirst()
    }

    private fun moveAppBefore(fromPackage: String, toPackage: String) {
        val current = allApps.map { it.activityInfo.packageName }.toMutableList()
        current.remove(fromPackage)
        val targetIndex = current.indexOf(toPackage).let { if (it < 0) current.size else it }
        current.add(targetIndex, fromPackage)
        orderedPackages.clear()
        orderedPackages.addAll(current)
        prefs.edit().putString("app_order", current.joinToString("|")).apply()
        allApps = allApps.sortedBy { app ->
            val i = orderedPackages.indexOf(app.activityInfo.packageName)
            if (i < 0) Int.MAX_VALUE else i
        }
        renderApps()
        Toast.makeText(this, "应用顺序已保存", Toast.LENGTH_SHORT).show()
    }

    private fun makeButton(label: String, size: Float, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            textSize = size
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(25, 39, 60))
            isFocusable = true
            isClickable = true
            setPadding(16, 8, 16, 8)
            setOnFocusChangeListener { v, focused ->
                v.background = rounded(if (focused) Color.rgb(0, 105, 150) else Color.rgb(25, 39, 60))
            }
            setOnClickListener { action() }
        }
    }

    private fun rounded(color: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = 12f }

    private fun showSettings() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 28, 40, 24)
            setBackgroundColor(Color.rgb(10, 16, 29))
            isFocusableInTouchMode = true
        }
        val heading = TextView(this).apply {
            text = "设置中心"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        panel.addView(heading)
        val note = TextView(this).apply {
            text = "创维 Android 9 适配版"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 20)
        }
        panel.addView(note)

        panel.addView(makeButton("选择本地壁纸", 18f) { chooseWallpaper() },
            LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 12 })
        panel.addView(makeButton("恢复默认深色背景", 18f) {
            prefs.edit().remove("wallpaper_uri").apply()
            showDesktop()
        }, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 12 })
        panel.addView(makeButton(if (showAppIcons) "隐藏应用图标" else "显示应用图标", 18f) {
            showAppIcons = !showAppIcons
            prefs.edit().putBoolean("show_app_icons", showAppIcons).apply()
            showDesktop()
        }, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 12 })
        panel.addView(makeButton("恢复应用默认排序", 18f) {
            prefs.edit().remove("app_order").apply()
            orderedPackages.clear()
            loadApps()
            showDesktop()
        }, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 12 })
        panel.addView(makeButton("清空收藏应用", 18f) {
            favoritePackages.clear()
            prefs.edit().remove("favorite_apps").apply()
            selectedCategory = "全部"
            showDesktop()
        }, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 12 })
        panel.addView(makeButton("遥控器排序使用说明", 18f) {
            Toast.makeText(this, "在桌面选中应用，按遥控器 MENU/菜单键进入排序；方向键移动；OK 保存；返回键退出编辑。", Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 12 })
        panel.addView(makeButton("刷新应用列表", 18f) {
            loadApps()
            showDesktop()
        }, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 12 })
        panel.addView(makeButton("返回桌面", 18f) { showDesktop() },
            LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 12 })

        val info = TextView(this).apply {
            text = "V6.0 新增：应用搜索、收藏分类、遥控器 STAR 键收藏/取消收藏。应用分类根据名称和包名自动判断；壁纸从电视本地文件中选择。若遥控器没有 STAR 键，可使用搜索与收藏分类，收藏键功能需后续按实际遥控器键值适配。"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 18, 0, 0)
        }
        panel.addView(info)
        setContentView(panel)
        panel.requestFocus()
    }

    private fun chooseWallpaper() {
        try {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(intent, 3001)
        } catch (_: Exception) {
            Toast.makeText(this, "电视文件选择器不可用", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 3001 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            prefs.edit().putString("wallpaper_uri", uri.toString()).apply()
            showDesktop()
        }
    }

    private fun applySavedWallpaper() {
        val uriText = prefs.getString("wallpaper_uri", null) ?: return
        try {
            val uri = Uri.parse(uriText)
            val image = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageURI(uri)
                alpha = 0.20f
            }
            // Background image is intentionally applied as a low-opacity drawable layer
            // only when the provider can decode the selected URI.
            root.background = android.graphics.drawable.BitmapDrawable(
                resources, contentResolver.openInputStream(uri)
            ).also { it.alpha = 48 }
        } catch (_: Exception) {
            prefs.edit().remove("wallpaper_uri").apply()
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (remoteSortMode) {
            cancelRemoteSortMode()
            return
        }
        // BACK is consumed so the desktop does not exit.
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (remoteSortMode) cancelRemoteSortMode()
            return true
        }

        // STAR key toggles the focused app in the favorites list.
        if (keyCode == KeyEvent.KEYCODE_STAR) {
            val visible = visibleApps()
            val focused = window.decorView.findFocus()
            val index = (0 until grid.childCount).firstOrNull { grid.getChildAt(it) === focused }
            val pkg = index?.let { visible.getOrNull(it)?.activityInfo?.packageName }
            if (pkg != null) {
                if (!favoritePackages.add(pkg)) favoritePackages.remove(pkg)
                prefs.edit().putString("favorite_apps", favoritePackages.joinToString("|")).apply()
                Toast.makeText(this, if (favoritePackages.contains(pkg)) "已加入收藏" else "已取消收藏", Toast.LENGTH_SHORT).show()
                renderApps()
            } else Toast.makeText(this, "请先选中一个应用", Toast.LENGTH_SHORT).show()
            return true
        }

        // Press MENU (or INFO on remotes that map the menu function to INFO)
        // to enter remote-only sorting mode.
        if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_INFO) {
            if (!remoteSortMode) enterRemoteSortMode()
            else saveRemoteOrder()
            return true
        }

        if (remoteSortMode) {
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> { moveFocusedApp(-1); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT -> { moveFocusedApp(1); return true }
                KeyEvent.KEYCODE_DPAD_UP -> { moveFocusedApp(-5); return true }
                KeyEvent.KEYCODE_DPAD_DOWN -> { moveFocusedApp(5); return true }
                KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_DPAD_CENTER -> {
                    saveRemoteOrder()
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}
