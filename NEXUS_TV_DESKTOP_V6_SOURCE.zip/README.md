# NEXUS TV DESKTOP V6.0

An Android TV launcher project targeting Android 9-compatible devices, including testing intended for Skyworth platform identifier `8A001_A3`.

## GitHub Actions build

This repository includes `.github/workflows/android.yml`. After pushing the project to GitHub, open the **Actions** tab and run or wait for **Build Android APK**. If the build succeeds, download the `nexus-tv-desktop-v6-debug` artifact from the workflow run.

## Build locally

Open this folder in Android Studio, allow Gradle sync, then select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.


Target: Skyworth ordinary smart TV, user-reported identifier `8A001_A3`, Android 9.
Generic Android 9 launcher source; not physically tested on the target television.

## V6.0 remote-only app sorting
1. Use the remote arrows to focus an app tile.
2. Press the remote's MENU / 菜单 key (some remotes map this function to INFO) to enter sorting mode.
3. Use LEFT / RIGHT to move one tile; UP / DOWN to move five positions in the app grid.
4. Press OK / ENTER to save the new order.
5. Press BACK to leave sorting mode without saving the temporary arrangement.

If the remote has no MENU key, use the Settings Center > 遥控器排序使用说明 to see the mapping notes; the exact key code depends on the remote/TV firmware.

## Retained features
- Android app icons and names.
- App drag-and-drop support where a pointer device is available.
- Saved app order.
- V3 wallpaper, automatic app categories, date/time, Settings Center.
- BACK key is consumed outside sorting mode.
- HOME intent filter and boot receiver attempt.

## Build and install
1. Open the project in Android Studio and sync Gradle.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. Install `app/build/outputs/apk/debug/app-debug.apk`.
4. Press HOME and select NEXUS TV DESKTOP as the default Home app.

## Notes
- Remote key mapping can vary by Skyworth firmware and remote model. MENU or INFO is used to enter sorting mode; test which key your remote sends.
- The app uses directional focus to select the tile; arrows in sorting mode move the selected app in the saved ordering.
- This build has not been compiled or physically tested on the Skyworth 8A001_A3 device.
- Android controls HOME routing; set this app as the default Home app.
- Android 9 / manufacturer firmware may restrict boot-time foreground launches.


## V6.0 新增
- 桌面顶部提供应用名称/包名搜索，输入时实时筛选。
- 新增“收藏”分类。
- 遥控器 `STAR` 键可收藏/取消收藏当前聚焦应用（不同遥控器键值可能不同）。
- 收藏状态保存在本机，重启后保留。
- 设置中心可清空收藏。
- 版本号升级为 6.0。

注意：本项目仍需 Android Studio 编译；尚未在实体创维电视上验证。若遥控器没有 STAR 键，需根据实际按键码进一步适配。


## Notes and limitations

- This repository is a source project, not a prebuilt APK.
- The project has not yet been compiled or tested on the physical target TV.
- Android controls HOME routing; set NEXUS TV DESKTOP as the default Home app in system settings.
- Boot-time app launches can be restricted by Android 9 or manufacturer firmware.
- Remote-control key codes vary by model; the STAR key favorite shortcut may need adjustment for a specific remote.
